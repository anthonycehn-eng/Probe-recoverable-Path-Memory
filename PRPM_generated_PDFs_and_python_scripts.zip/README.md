# PRPM Generated Figures Package

This package contains the unique PDF figures generated during the PRPM manuscript-development workflow, plus Python scripts for regenerating the figures.

## Contents

- `figures_pdf/`: 30 unique PDF figures.
- `python_scripts/`: scripts used to generate or regenerate the figure families.
- `manifest.csv`: filename, size, and SHA-256 checksum for each included PDF/script.

## Data-dependent scripts

The FRET, public-dataset, and evidence-summary scripts expect the processed package root as `--data-dir`, containing folders such as:

- `02_ground_truth_fret_benchmark/`
- `03_smfret_burst_benchmark/`
- `04_myosin5b_motor_pilot/`
- `05_riboswitch_aggregate_module/`

Example:

```bash
python python_scripts/generate_all_figures.py --data-dir ./prpm_full_data_package --out-dir ./regenerated_figures
```

The core architecture and early CTMC/concept scripts are standalone.

## Notes

This package intentionally excludes full manuscript PDFs and uploaded source PDFs; it contains the generated figure PDFs only.
