#!/usr/bin/env python3
"""
Generate CTMC validation and early conceptual PRPM figures.
These are standalone and do not require the processed data package.
Usage:
  python 05_generate_ctmc_and_early_concept_figures.py --out-dir ./figures_pdf
"""
import argparse
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Ellipse

blue="#4c78a8"; light_blue="#9ecae1"; green="#74c476"; dark_green="#238b45"; gray="#6b6b6b"; light_gray="#e6e6e6"; dark="#2f2f2f"

def save(fig,out_dir,name):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    fig.savefig(out/f"{name}.pdf",bbox_inches="tight"); fig.savefig(out/f"{name}.png",dpi=300,bbox_inches="tight"); plt.close(fig)

def main(out_dir):
    # CTMC washout
    t=np.array([0,0.25,0.5,1.0,2.0,3.0])
    hidden=np.array([5.935e-2,2.15e-2,7.84e-3,1.06e-3,1.78e-5,3.55e-7])
    response=np.array([6.41e-3,2.34e-3,8.64e-4,1.17e-4,2.05e-6,3.92e-8])
    fig,ax=plt.subplots(figsize=(6.0,3.8)); ax.plot(t,hidden,marker='o',label=r"$I(D;X_T\mid Y_T)$"); ax.plot(t,response,marker='s',label=r"$I(D;Y_{T+1}\mid Y_T)$"); ax.set_yscale('log'); ax.set_xlabel('hidden equilibration time before readout'); ax.set_ylabel('information (bits)'); ax.set_title('Hidden equilibration washout in the CTMC witness'); ax.legend(frameon=False); ax.grid(alpha=0.25); fig.tight_layout(); save(fig,out_dir,'ctmc_hidden_equilibration_washout_clean')
    # CTMC hidden composition histogram
    labels=[r'$A_0$',r'$A_1$',r'$B_0$',r'$B_1$']; p0=np.array([0.15,0.35,0.25,0.25]); p1=np.array([0.35,0.15,0.25,0.25]); x=np.arange(4); w=0.36
    fig,ax=plt.subplots(figsize=(5.8,3.6)); ax.bar(x-w/2,p0,w,label=r'$D=0$',color=light_blue); ax.bar(x+w/2,p1,w,label=r'$D=1$',color=green); ax.set_xticks(x); ax.set_xticklabels(labels); ax.set_ylabel('probability'); ax.set_title('CTMC preparation distributions with matched observed state'); ax.legend(frameon=False); fig.tight_layout(); save(fig,out_dir,'ctmc_preparation_hidden_composition_histogram')
    # CTMC response scatter
    fig,ax=plt.subplots(figsize=(5.6,3.6)); ax.scatter([0,1],[0.61797,0.74208],s=90,color=green,label='non-lumpable A-fiber'); ax.scatter([0,1],[0.60095,0.60095],s=70,color=gray,label='lumpable control'); ax.set_xticks([0,1]); ax.set_xticklabels([r'$D=0$',r'$D=1$']); ax.set_ylabel(r'$\Pr(Y_{T+1}=A\mid Y_T=A,D)$'); ax.set_title('Response law separation under non-lumpable dynamics'); ax.legend(frameon=False); ax.set_ylim(0.55,0.78); fig.tight_layout(); save(fig,out_dir,'ctmc_response_law_scatter')
    # Early conceptual framework flow
    fig,ax=plt.subplots(figsize=(7.0,3.8)); ax.set_xlim(0,1); ax.set_ylim(0,1); ax.axis('off')
    xs=[0.15,0.38,0.62,0.85]; texts=[r'preparation\n$D$',r'full state\n$X_T$',r'observed\n$Y_T=\pi(X_T)$',r'future response\n$Z^Q$']
    for x0,txt in zip(xs,texts):
        ax.add_patch(FancyBboxPatch((x0-0.09,0.44),0.18,0.14,boxstyle='round,pad=0.02',fc='white',ec=blue,lw=1.2)); ax.text(x0,0.51,txt,ha='center',va='center',fontsize=10)
    for a,b in zip(xs[:-1],xs[1:]): ax.add_patch(FancyArrowPatch((a+0.09,0.51),(b-0.09,0.51),arrowstyle='-|>',mutation_scale=12,color=dark,lw=1.2))
    ax.text(0.5,0.22,r'$I(D;Y_T)=0$ but $I(D;Z^Q\mid Y_T)>0$',ha='center',fontsize=12); ax.set_title('PRPM framework information flow'); fig.tight_layout(); save(fig,out_dir,'prpm_framework_fiber_readout')
    # Geometric simplex figures
    for name, clean in [('prpm_geometric_simplex_fiber',False),('prpm_geometric_simplex_fiber_clean_blue',True)]:
        fig,ax=plt.subplots(figsize=(5.5,4.5)); ax.set_xlim(-0.1,1.1); ax.set_ylim(-0.1,1.0); ax.axis('off')
        tri=np.array([[0.08,0.08],[0.92,0.08],[0.50,0.84],[0.08,0.08]]); ax.plot(tri[:,0],tri[:,1],color=dark,lw=1.2)
        for x0 in [0.28,0.50,0.72]: ax.plot([x0,x0],[0.12,0.72-0.8*abs(x0-0.5)],color=blue,alpha=0.5,lw=1)
        ax.scatter([0.44,0.56],[0.50,0.62],s=70,color=[green,blue],edgecolor='white',zorder=5); ax.plot([0.44,0.50],[0.50,0.08],ls=':',color=gray); ax.plot([0.56,0.50],[0.62,0.08],ls=':',color=gray)
        if not clean:
            ax.text(0.18,0.86,'full-state simplex',fontsize=11); ax.text(0.55,0.11,'same observed projection',fontsize=9,color=gray)
        ax.text(0.44,0.48,r'$p_T^0$',fontsize=9); ax.text(0.58,0.64,r'$p_T^1$',fontsize=9); ax.set_title('Observation fiber inside the probability simplex'); fig.tight_layout(); save(fig,out_dir,name)
    # Nullspace readout geometry early
    fig,ax=plt.subplots(figsize=(5.8,4.6)); ax.set_xlim(-1,1.2); ax.set_ylim(-0.8,1.2); ax.axis('off')
    ax.add_patch(FancyArrowPatch((-0.8,0),(1.0,0),arrowstyle='-|>',mutation_scale=12,color=dark)); ax.add_patch(FancyArrowPatch((0,-0.6),(0,1.0),arrowstyle='-|>',mutation_scale=12,color=dark))
    ax.add_patch(FancyArrowPatch((0,0),(0,0.75),arrowstyle='-|>',mutation_scale=14,color=blue,lw=2)); ax.add_patch(FancyArrowPatch((0,0),(0.78,0.48),arrowstyle='-|>',mutation_scale=14,color=green,lw=2))
    ax.text(-0.65,0.6,r'$\delta p_T\in\ker\Pi$',color=blue); ax.text(0.42,0.58,r'$e^{\tau Q}\delta p_T$',color=green); ax.text(0.35,-0.16,'observed readout',color=dark); ax.set_title('Nullspace readout geometry'); fig.tight_layout(); save(fig,out_dir,'prpm_nullspace_readout_geometry')

if __name__ == '__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('--out-dir',default='./figures_pdf'); args=parser.parse_args(); main(args.out_dir)
