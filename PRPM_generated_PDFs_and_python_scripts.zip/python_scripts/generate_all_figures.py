#!/usr/bin/env python3
"""
Convenience runner for all figure scripts.
Requires matplotlib, numpy, pandas, scipy, h5py.
Usage:
  python generate_all_figures.py --data-dir ./prpm_full_data_package --out-dir ./figures_pdf
"""
import argparse, subprocess, sys
from pathlib import Path

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", required=True)
    parser.add_argument("--out-dir", default="./figures_pdf")
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    scripts = [
        ("01_generate_core_architecture_figures.py", ["--out-dir", args.out_dir]),
        ("02_generate_fret_benchmark_figures.py", ["--data-dir", args.data_dir, "--out-dir", args.out_dir]),
        ("03_generate_public_dataset_figures.py", ["--data-dir", args.data_dir, "--out-dir", args.out_dir]),
        ("04_generate_system_summary_figures.py", ["--data-dir", args.data_dir, "--out-dir", args.out_dir]),
        ("05_generate_ctmc_and_early_concept_figures.py", ["--out-dir", args.out_dir]),
    ]
    for script, extra in scripts:
        subprocess.check_call([sys.executable, str(here / script), *extra])
