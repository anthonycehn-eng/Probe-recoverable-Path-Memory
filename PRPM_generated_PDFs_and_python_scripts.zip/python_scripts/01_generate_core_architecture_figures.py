#!/usr/bin/env python3
"""
Generate the core PRPM architecture figures:
- coreA_observation_fiber_readout_bundle.pdf
- coreB_nullspace_to_readout_geometry.pdf
- coreC_information_architecture_triad.pdf
- coreD_response_factorization_failure.pdf
- coreE_fiber_transport_manifold.pdf

Usage:
  python 01_generate_core_architecture_figures.py --out-dir ./figures_pdf
"""
import argparse
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Ellipse
from pathlib import Path

blue = "#3B6EA8"
light_blue = "#CFE2F3"
green = "#5CB85C"
light_green = "#D9EFD3"
gray = "#6B7280"
light_gray = "#ECEFF3"
dark = "#1F2937"
orange = "#E8A23A"

def savefig(fig, out_dir, name):
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_dir / f"{name}.pdf", bbox_inches="tight")
    fig.savefig(out_dir / f"{name}.png", dpi=320, bbox_inches="tight")
    plt.close(fig)

def core_a(out_dir):
    fig, axes = plt.subplots(1, 3, figsize=(12.6, 4.0))
    for ax in axes:
        ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    ax = axes[0]
    ax.text(0.03, 0.94, "A", fontsize=13, fontweight="bold", color=dark)
    ax.text(0.50, 0.94, "Observation fibers", ha="center", fontsize=12, color=dark)
    ax.plot([0.15, 0.85], [0.18, 0.18], color=dark, lw=1.4)
    ax.text(0.15, 0.10, r"$y=A$", ha="center", fontsize=10)
    ax.text(0.85, 0.10, r"$y=B$", ha="center", fontsize=10)
    ax.text(0.50, 0.04, r"observed base $Y_T$", ha="center", fontsize=10, color=gray)
    for x, lab in [(0.15, r"$F_A=\pi^{-1}(A)$"), (0.85, r"$F_B=\pi^{-1}(B)$")]:
        ax.plot([x, x], [0.18, 0.78], color=blue, lw=1.5)
        ax.add_patch(Ellipse((x, 0.48), 0.16, 0.56, fill=False, ec=blue, lw=1.1, alpha=0.9))
        ax.text(x, 0.82, lab, ha="center", fontsize=9, color=blue)
    ax.scatter([0.12, 0.18], [0.54, 0.64], s=62, color=green, edgecolor="white", zorder=5)
    ax.text(0.07, 0.54, r"$p_T^0$", fontsize=9, color=dark)
    ax.text(0.20, 0.65, r"$p_T^1$", fontsize=9, color=dark)
    for x0, y0 in [(0.12, 0.54), (0.18, 0.64)]:
        ax.plot([x0, 0.15], [y0, 0.18], ls=":", lw=1.0, color=gray)
    ax.text(0.28, 0.36, r"same shadow" + "\n" + r"$\Pi p_T^0=\Pi p_T^1$", fontsize=9, color=dark)

    ax = axes[1]
    ax.text(0.03, 0.94, "B", fontsize=13, fontweight="bold", color=dark)
    ax.text(0.50, 0.94, "Endpoint collapse", ha="center", fontsize=12, color=dark)
    ax.add_patch(Ellipse((0.35, 0.62), 0.20, 0.26, fill=True, fc=light_green, ec=green, lw=1.2))
    ax.add_patch(Ellipse((0.65, 0.62), 0.20, 0.26, fill=True, fc=light_blue, ec=blue, lw=1.2))
    ax.text(0.35, 0.62, r"$\mu_y^0$", ha="center", va="center", fontsize=11, color=dark)
    ax.text(0.65, 0.62, r"$\mu_y^1$", ha="center", va="center", fontsize=11, color=dark)
    ax.add_patch(FancyArrowPatch((0.35, 0.48), (0.50, 0.25), arrowstyle="-|>", mutation_scale=12, lw=1.2, color=gray))
    ax.add_patch(FancyArrowPatch((0.65, 0.48), (0.50, 0.25), arrowstyle="-|>", mutation_scale=12, lw=1.2, color=gray))
    ax.add_patch(FancyBboxPatch((0.33, 0.16), 0.34, 0.13, boxstyle="round,pad=0.015,rounding_size=0.02", fc=light_gray, ec=gray, lw=1.1))
    ax.text(0.50, 0.225, r"$Y_T=y$", ha="center", va="center", fontsize=12, color=dark)
    ax.text(0.50, 0.08, r"$I(D;Y_T)=0$", ha="center", fontsize=11, color=dark)

    ax = axes[2]
    ax.text(0.03, 0.94, "C", fontsize=13, fontweight="bold", color=dark)
    ax.text(0.50, 0.94, "Probe transport", ha="center", fontsize=12, color=dark)
    ax.plot([0.20, 0.20], [0.25, 0.75], color=blue, lw=1.4)
    ax.scatter([0.20, 0.20], [0.42, 0.62], s=58, color=[green, blue], edgecolor="white", zorder=5)
    ax.text(0.12, 0.52, r"$\delta p_T\in\ker\Pi$", fontsize=10, color=dark, rotation=90, ha="center", va="center")
    ax.add_patch(FancyArrowPatch((0.30, 0.52), (0.55, 0.52), arrowstyle="-|>", mutation_scale=14, lw=1.5, color=dark))
    ax.text(0.425, 0.57, r"$e^{\tau Q}$", ha="center", fontsize=11)
    ax.plot([0.68, 0.68], [0.25, 0.75], color=blue, lw=1.1, alpha=0.5)
    ax.scatter([0.64, 0.75], [0.42, 0.62], s=58, color=[green, blue], edgecolor="white", zorder=5)
    ax.plot([0.64, 0.64], [0.18, 0.42], ls=":", lw=1.0, color=gray)
    ax.plot([0.75, 0.75], [0.18, 0.62], ls=":", lw=1.0, color=gray)
    ax.plot([0.56, 0.84], [0.18, 0.18], color=dark, lw=1.2)
    ax.text(0.64, 0.10, r"$Y'$", ha="center", fontsize=10)
    ax.text(0.75, 0.10, r"$Y''$", ha="center", fontsize=10)
    ax.text(0.70, 0.04, r"separated observed futures", ha="center", fontsize=9, color=gray)
    ax.text(0.48, 0.26, r"$\Pi e^{\tau Q}\delta p_T\neq0$", fontsize=10, color=dark)
    fig.suptitle("Observation-Fiber Readout Bundle", fontsize=15, y=1.02)
    savefig(fig, out_dir, "coreA_observation_fiber_readout_bundle")

def core_b(out_dir):
    fig, ax = plt.subplots(figsize=(6.4, 5.2))
    ax.set_xlim(-1.4, 1.6); ax.set_ylim(-1.25, 1.55); ax.axis("off")
    ax.add_patch(FancyArrowPatch((-1.15, 0), (1.35, 0), arrowstyle="-|>", mutation_scale=13, lw=1.3, color=dark))
    ax.add_patch(FancyArrowPatch((0, -1.0), (0, 1.3), arrowstyle="-|>", mutation_scale=13, lw=1.3, color=dark))
    ax.text(1.35, -0.08, r"observed coordinate $\operatorname{im}\Pi$", ha="right", fontsize=10, color=dark)
    ax.text(0.05, 1.25, r"hidden coordinate $\ker\Pi$", fontsize=10, color=dark)
    ax.add_patch(FancyArrowPatch((0, 0), (0, 0.95), arrowstyle="-|>", mutation_scale=14, lw=2, color=blue))
    ax.text(-0.55, 0.78, r"$\delta p_T$", fontsize=12, color=blue)
    ax.text(-0.68, 0.60, r"$\Pi\delta p_T=0$", fontsize=10, color=gray)
    ax.add_patch(FancyArrowPatch((0, 0), (1.05, 0.76), arrowstyle="-|>", mutation_scale=14, lw=2, color=green))
    ax.text(0.58, 0.86, r"$e^{\tau Q}\delta p_T$", fontsize=12, color=green)
    ax.plot([1.05, 1.05], [0, 0.76], ls=":", lw=1.1, color=gray)
    ax.plot([0, 1.05], [0.76, 0.76], ls=":", lw=1.1, color=gray)
    ax.text(0.60, -0.18, r"readout component", fontsize=10, color=dark)
    ax.text(0.47, -0.38, r"$\Pi e^{\tau Q}\delta p_T\neq0$", fontsize=11, color=dark)
    ax.add_patch(FancyArrowPatch((0, 0), (0, -0.82), arrowstyle="-|>", mutation_scale=13, lw=1.7, color=gray, linestyle="--"))
    ax.text(0.07, -0.75, "lumpable evolution\nstays hidden", fontsize=9, color=gray, va="center")
    ax.add_patch(FancyBboxPatch((-1.05, 1.03), 0.70, 0.18, boxstyle="round,pad=0.015,rounding_size=0.02", fc=light_blue, ec=blue, lw=1.0))
    ax.text(-0.70, 1.12, "stored but invisible", ha="center", va="center", fontsize=9)
    ax.add_patch(FancyBboxPatch((0.60, 1.10), 0.72, 0.18, boxstyle="round,pad=0.015,rounding_size=0.02", fc=light_green, ec=green, lw=1.0))
    ax.text(0.96, 1.19, "stored and readable", ha="center", va="center", fontsize=9)
    ax.set_title("Nullspace-to-Readout Geometry", fontsize=15, pad=8)
    savefig(fig, out_dir, "coreB_nullspace_to_readout_geometry")

def core_c(out_dir):
    fig, ax = plt.subplots(figsize=(7.0, 5.4))
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    pos = {"D": (0.13, 0.55), "Y": (0.50, 0.78), "X": (0.50, 0.34), "Z": (0.86, 0.55)}
    labels = {"D": r"history / prep" + "\n" + r"$D$", "Y": r"observed present" + "\n" + r"$Y_T=\pi(X_T)$", "X": r"full hidden state" + "\n" + r"$X_T$", "Z": r"future response" + "\n" + r"$Z^Q_{T:T+\tau}$"}
    colors = {"D": light_gray, "Y": light_blue, "X": light_green, "Z": light_gray}
    edges = {"D": gray, "Y": blue, "X": green, "Z": gray}
    for key, (x, y) in pos.items():
        ax.add_patch(FancyBboxPatch((x-0.11, y-0.055), 0.22, 0.11, boxstyle="round,pad=0.015,rounding_size=0.025", fc=colors[key], ec=edges[key], lw=1.2))
        ax.text(x, y, labels[key], ha="center", va="center", fontsize=9.5, color=dark)
    def arrow(a, b, text=None, curve=0.0, color=dark):
        x1, y1 = pos[a]; x2, y2 = pos[b]
        ax.add_patch(FancyArrowPatch((x1+0.11*np.sign(x2-x1), y1), (x2-0.11*np.sign(x2-x1), y2), arrowstyle="-|>", mutation_scale=13, lw=1.15, color=color, connectionstyle=f"arc3,rad={curve}"))
        if text:
            ax.text((x1+x2)/2, (y1+y2)/2 + (0.08 if curve >= 0 else -0.08), text, ha="center", va="center", fontsize=9, color=color)
    arrow("D", "Y", r"$I(D;Y_T)$", curve=0.15, color=blue)
    arrow("D", "X", r"$I(D;X_T\mid Y_T)$", curve=-0.15, color=green)
    arrow("X", "Z", None, color=dark)
    arrow("D", "Z", r"$I(D;Z\mid Y_T)$", color=gray)
    ax.add_patch(FancyArrowPatch((0.50, 0.41), (0.50, 0.70), arrowstyle="-|>", mutation_scale=13, lw=1.3, color=blue))
    ax.text(0.535, 0.56, r"$\pi$", fontsize=12, color=blue)
    ax.add_patch(FancyBboxPatch((0.22, 0.05), 0.56, 0.13, boxstyle="round,pad=0.018,rounding_size=0.025", fc="white", ec=gray, lw=1.0))
    ax.text(0.50, 0.115, r"$I(D;Y_T)=0\quad\mathrm{but}\quad I(D;Z^Q_{T:T+\tau}\mid Y_T)>0$", ha="center", va="center", fontsize=11, color=dark)
    ax.text(0.50, 0.94, "Information Architecture of PRPM", ha="center", fontsize=15)
    ax.text(0.50, 0.90, "visible endpoint imprint, hidden storage, and response recoverability are distinct", ha="center", fontsize=9, color=gray)
    savefig(fig, out_dir, "coreC_information_architecture_triad")

def core_d(out_dir):
    fig, ax = plt.subplots(figsize=(7.2, 5.0))
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    nodes = {"X": (0.18, 0.62), "Y": (0.50, 0.62), "Z": (0.82, 0.62), "D": (0.18, 0.28), "fail": (0.82, 0.28)}
    texts = {"X": r"$X_T$" + "\nfull state", "Y": r"$Y_T$" + "\nobserved", "Z": r"$\mathcal{L}(Z_\tau)$" + "\nresponse law", "D": r"$D$" + "\npreparation", "fail": "factorization fails\nthrough observed state"}
    for k, (x, y) in nodes.items():
        fc = light_blue if k == "Y" else light_green if k == "X" else light_gray
        ec = blue if k == "Y" else green if k == "X" else gray
        ax.add_patch(FancyBboxPatch((x-0.11, y-0.065), 0.22, 0.13, boxstyle="round,pad=0.015,rounding_size=0.025", fc=fc, ec=ec, lw=1.2))
        ax.text(x, y, texts[k], ha="center", va="center", fontsize=9.5, color=dark)
    ax.add_patch(FancyArrowPatch((0.29, 0.62), (0.71, 0.62), arrowstyle="-|>", mutation_scale=13, lw=1.3, color=green))
    ax.text(0.50, 0.68, r"$B_\tau(z\mid x)$", ha="center", fontsize=10, color=green)
    ax.add_patch(FancyArrowPatch((0.29, 0.67), (0.39, 0.67), arrowstyle="-|>", mutation_scale=13, lw=1.2, color=blue))
    ax.text(0.34, 0.72, r"$\pi$", ha="center", fontsize=11, color=blue)
    ax.add_patch(FancyArrowPatch((0.61, 0.67), (0.71, 0.67), arrowstyle="-|>", mutation_scale=13, lw=1.2, color=gray, linestyle="--"))
    ax.text(0.66, 0.73, r"$\bar B_\tau(z\mid y)$?", ha="center", fontsize=10, color=gray)
    ax.plot([0.655, 0.685], [0.665, 0.695], color=orange, lw=2)
    ax.plot([0.685, 0.655], [0.665, 0.695], color=orange, lw=2)
    ax.add_patch(FancyArrowPatch((0.18, 0.35), (0.18, 0.53), arrowstyle="-|>", mutation_scale=13, lw=1.15, color=gray))
    ax.text(0.07, 0.44, r"$\mu_y^d$", fontsize=10, color=gray)
    ax.add_patch(FancyArrowPatch((0.50, 0.55), (0.74, 0.34), arrowstyle="-|>", mutation_scale=13, lw=1.1, color=orange))
    ax.text(0.52, 0.42, r"$B_{\tau,y}\mu_y^0\neq B_{\tau,y}\mu_y^1$", ha="center", fontsize=10, color=orange)
    ax.add_patch(FancyBboxPatch((0.20, 0.06), 0.60, 0.12, boxstyle="round,pad=0.018,rounding_size=0.025", fc="white", ec=gray, lw=1.0))
    ax.text(0.50, 0.12, r"PRPM detects failure of response factorization through $Y_T$", ha="center", va="center", fontsize=11, color=dark)
    ax.text(0.50, 0.93, "Response-Factorization Failure", ha="center", fontsize=15)
    ax.text(0.50, 0.89, r"observed state suffices iff response law factors through $Y_T$", ha="center", fontsize=9, color=gray)
    savefig(fig, out_dir, "coreD_response_factorization_failure")

def core_e(out_dir):
    fig = plt.figure(figsize=(7.0, 5.2))
    ax = fig.add_subplot(111, projection="3d")
    ys = np.linspace(-1, 1, 50)
    ax.plot(ys, np.zeros_like(ys), np.zeros_like(ys), color=dark, lw=1.2)
    for yy in [-0.55, 0.55]:
        ax.plot([yy, yy], [0, 0], [0, 1.0], color=blue, lw=1.1, alpha=0.8)
    p0 = np.array([-0.55, 0, 0.35]); p1 = np.array([-0.55, 0, 0.80])
    q0 = np.array([0.25, 0, 0.45]); q1 = np.array([0.55, 0, 0.77])
    ax.scatter(*p0, s=55, color=green, edgecolor="white")
    ax.scatter(*p1, s=55, color=blue, edgecolor="white")
    ax.scatter(*q0, s=55, color=green, marker="D", edgecolor="white")
    ax.scatter(*q1, s=55, color=blue, marker="D", edgecolor="white")
    def arrow3(a, b, color):
        v = b-a
        ax.quiver(a[0], a[1], a[2], v[0], v[1], v[2], arrow_length_ratio=0.12, color=color, lw=1.2)
    arrow3(p0, q0, green); arrow3(p1, q1, blue)
    for p in [p0, p1, q0, q1]:
        ax.plot([p[0], p[0]], [0, 0], [p[2], 0], ls=":", lw=0.8, color=gray)
    ax.text(-0.55, 0, 1.08, r"fiber $F_y$", color=blue, ha="center")
    ax.text(-0.55, 0, -0.12, r"same $Y_T$", ha="center", color=dark)
    ax.text(0.40, 0, -0.12, r"separated future $Y_{T+\tau}$", ha="center", color=dark)
    ax.text(-0.85, 0, 0.55, r"$\delta p_T$ vertical", color=dark)
    ax.text(0.15, 0, 0.92, r"probe tilts hidden separation", color=dark)
    ax.set_title("Fiber-Transport Manifold", pad=12, fontsize=15)
    ax.set_xlabel("observed coordinate"); ax.set_ylabel(""); ax.set_zlabel("hidden fiber coordinate")
    ax.set_yticks([]); ax.view_init(elev=22, azim=-58); ax.grid(False)
    fig.tight_layout()
    savefig(fig, out_dir, "coreE_fiber_transport_manifold")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--out-dir", default="./figures_pdf")
    args = parser.parse_args()
    core_a(args.out_dir); core_b(args.out_dir); core_c(args.out_dir); core_d(args.out_dir); core_e(args.out_dir)
