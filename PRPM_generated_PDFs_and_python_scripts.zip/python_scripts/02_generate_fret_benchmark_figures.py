#!/usr/bin/env python3
"""
Generate PRPM ground-truth smFRET benchmark figures from the processed package.
Expected data root contains: 02_ground_truth_fret_benchmark/
Usage:
  python 02_generate_fret_benchmark_figures.py --data-dir ./prpm_full_data_package --out-dir ./figures_pdf
"""
import argparse
from pathlib import Path
import h5py
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

blue = "#4c78a8"; light_blue = "#9ecae1"; green = "#74c476"; dark_green = "#238b45"; gray = "#6b6b6b"; light_gray = "#e6e6e6"

def save(fig, out_dir, name):
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    fig.savefig(out / f"{name}.pdf", bbox_inches="tight")
    fig.savefig(out / f"{name}.png", dpi=300, bbox_inches="tight")
    plt.close(fig)

def main(data_dir, out_dir):
    base = Path(data_dir) / "02_ground_truth_fret_benchmark"
    dt = 0.05
    summary = pd.read_csv(base / "path_memory_summary.csv")

    with h5py.File(base / "test_trace_poissonian.h5", "r") as f:
        donor = f["donor_channel"][:].astype(float)
        acceptor = f["acceptor_channel"][:].astype(float)
    with h5py.File(base / "gt_test_trace_poissonian.h5", "r") as f:
        hidden = f["binned_trajectory"][:].astype(int)
    Eraw = acceptor / np.maximum(donor + acceptor, 1)
    t = np.arange(len(Eraw)) * dt
    thresh = float(summary.loc[summary["dataset"] == "poissonian", "E_threshold"].iloc[0])

    # Trace
    mask = (t >= 35) & (t <= 65)
    fig, ax = plt.subplots(figsize=(6.4, 3.8))
    ax.plot(t[mask], Eraw[mask], linewidth=0.9, label=r"$E_{\rm raw}=A/(D+A)$")
    ax.axhline(thresh, linestyle="--", linewidth=1.0, label="observation threshold")
    start = None
    for i, (tt, st) in enumerate(zip(t[mask], hidden[mask])):
        if st == 2 and start is None:
            start = tt
        next_is_end = (st == 2) and (i == len(hidden[mask])-1 or hidden[mask][i+1] != 2)
        if next_is_end and start is not None:
            ax.axvspan(start, tt + dt, alpha=0.12)
            start = None
    ax.set_xlabel("Time (s)"); ax.set_ylabel(r"$E_{\rm raw}$"); ax.set_title("Ground-truth FRET benchmark: noisy observed present")
    ax.set_ylim(-0.02, 0.92); ax.legend(frameon=False, loc="upper right"); fig.tight_layout()
    save(fig, out_dir, "fret_poissonian_trace_clean")

    # Observation overlap old and green use similar plot
    state_vals = [Eraw[hidden == 1], Eraw[hidden == 2]]
    for suffix, use_green in [("", False), ("_green", True)]:
        fig, ax = plt.subplots(figsize=(5.2, 3.8))
        ax.boxplot(state_vals, positions=[0, 1], widths=0.42, showfliers=False, patch_artist=True,
                   boxprops=dict(facecolor=light_blue, edgecolor=blue, linewidth=1.0),
                   medianprops=dict(color=dark_green, linewidth=1.2),
                   whiskerprops=dict(color=blue, linewidth=1.0), capprops=dict(color=blue, linewidth=1.0))
        rng = np.random.default_rng(7)
        for i, vals in enumerate(state_vals):
            idx = rng.choice(len(vals), size=min(350, len(vals)), replace=False)
            ax.scatter(np.full(len(idx), i) + rng.normal(0, 0.05, len(idx)), vals[idx], s=6, alpha=0.25, color=(green if (use_green and i==1) else blue))
        ax.axhline(thresh, linestyle="--", linewidth=1.1, color=dark_green, label=f"threshold = {thresh:.3f}")
        ax.set_xticks([0, 1]); ax.set_xticklabels([r"$X_t=1$", r"$X_t=2$"])
        ax.set_ylabel(r"$E_{\rm raw}$"); ax.set_title("Observed FRET overlap by hidden state")
        ax.set_ylim(-0.02, 0.92); ax.legend(frameon=False); fig.tight_layout()
        save(fig, out_dir, f"fret_observation_overlap_by_hidden_state{suffix}")

    # Balanced CMI
    balanced = pd.read_csv(base / "balanced_fiber_matched_resamples.csv")
    poiss = balanced[balanced["dataset"] == "poissonian"]["I(D;Z|Y)_bits"].to_numpy()
    fig, ax = plt.subplots(figsize=(5.8, 3.6))
    ax.hist(poiss, bins=32)
    ax.axvline(poiss.mean(), linestyle="--", linewidth=1.2, label=f"mean = {poiss.mean():.3f} bits")
    lo, hi = np.quantile(poiss, [0.025, 0.975])
    ax.axvline(lo, linestyle=":", linewidth=1.0, label="95% interval"); ax.axvline(hi, linestyle=":", linewidth=1.0)
    ax.set_xlabel(r"Balanced-resample $I(D;Z\mid Y)$ (bits)"); ax.set_ylabel("Resamples")
    ax.set_title("Matched-present recovery over balanced resamples"); ax.legend(frameon=False); fig.tight_layout()
    save(fig, out_dir, "fret_poissonian_balanced_cmi_clean")

    # Permutation/null histogram old and log effect-size versions
    perm = pd.read_csv(base / "path_memory_permutation_values.csv")
    obs_col = "observed_cmi" if "observed_cmi" in perm.columns else "observed_CMI_bits"
    val_col = "perm_cmi" if "perm_cmi" in perm.columns else [c for c in perm.columns if "perm" in c and "cmi" in c.lower()][0]
    assay = "hidden_prev_to_hidden_next_given_Yobs" if "hidden_prev_to_hidden_next_given_Yobs" in set(perm["assay"]) else "hidden_prev_to_hidden_next_given_observed_current"
    sub = perm[(perm["dataset"] == "poissonian") & (perm["assay"] == assay)].copy()
    null_vals = sub[val_col].to_numpy(); obs = float(sub[obs_col].iloc[0])
    pval = float(sub["p_value"].iloc[0]) if "p_value" in sub.columns else (np.sum(null_vals >= obs)+1)/(len(null_vals)+1)
    fig, ax = plt.subplots(figsize=(5.8, 3.6))
    ax.hist(null_vals, bins=40); ax.axvline(obs, linestyle="--", linewidth=1.2, label=f"observed = {obs:.3f} bits")
    ax.set_xlabel(r"Conditional-shuffle null $I(D;Z\mid Y)$ (bits)"); ax.set_ylabel("Permutations")
    ax.set_title("Hidden-history CMI against conditional-shuffle null"); ax.legend(frameon=False); fig.tight_layout()
    save(fig, out_dir, "fret_poissonian_hidden_history_permutation_clean")

    for suffix, use_green in [("", False), ("_green", True)]:
        rng = np.random.default_rng(7); sample_idx = rng.choice(len(null_vals), size=min(1200, len(null_vals)), replace=False)
        jitter = rng.normal(0, 0.035, size=len(sample_idx)); q99 = float(np.quantile(null_vals, 0.99))
        fig, ax = plt.subplots(figsize=(6.2, 3.6))
        ax.scatter(null_vals[sample_idx], np.zeros(len(sample_idx)) + jitter, s=8, alpha=0.28, color=blue, label="conditional-shuffle null")
        ax.boxplot(null_vals, vert=False, positions=[0], widths=0.28, showfliers=False, patch_artist=False,
                   boxprops=dict(color=blue), medianprops=dict(color=dark_green), whiskerprops=dict(color=blue), capprops=dict(color=blue))
        ax.scatter([obs], [0], s=95, marker="D", color=(green if use_green else blue), edgecolor=dark_green, linewidth=0.8, label="observed")
        ax.axvline(q99, linestyle=":", linewidth=1.1, color=gray, label="99th percentile null"); ax.axvline(obs, linestyle="--", linewidth=1.1, color=dark_green)
        ax.set_xscale("log"); ax.set_yticks([]); ax.set_xlabel(r"$I(D_t;Z_t\mid Y_t)$ (bits), log scale")
        ax.set_title("Conditional-shuffle null versus observed response memory")
        ax.text(obs, 0.19, f"observed = {obs:.3f} bits\np = {pval:.4f}", ha="right", va="bottom", fontsize=9, color=dark_green)
        ax.text(q99, -0.22, f"99% null = {q99:.3g}", ha="center", va="top", fontsize=8, color=gray)
        ax.legend(frameon=False, loc="upper left"); fig.tight_layout()
        save(fig, out_dir, f"fret_poissonian_null_effectsize_logplot{suffix}")

    # Sufficiency ladder
    rows=[]
    for _, r in summary.iterrows():
        label = "Poissonian" if r["dataset"] == "poissonian" else "High-separability"
        rows += [{"dataset": label, "metric": r"$I(D;Y)$", "value": r["I(D_hidden_prev;Y_obs_current)_bits"]},
                 {"dataset": label, "metric": r"$I(D;Z)$", "value": r["I(D_hidden_prev;Z_hidden_next)_bits"]},
                 {"dataset": label, "metric": r"$I(D;Z\mid Y)$", "value": r["I(D_hidden_prev;Z_hidden_next|Y_obs_current)_bits"]},
                 {"dataset": label, "metric": r"$I(D;Z\mid X)$", "value": r["I(D_hidden_prev;Z_hidden_next|X_current)_bits_markov_sufficiency_control"]}]
    ladder=pd.DataFrame(rows); metrics=ladder["metric"].unique(); x=np.arange(len(metrics)); width=0.36
    fig, ax = plt.subplots(figsize=(6.5, 3.8))
    for j, dataset in enumerate(["Poissonian", "High-separability"]):
        vals=[ladder[(ladder["dataset"]==dataset)&(ladder["metric"]==m)]["value"].iloc[0] for m in metrics]
        ax.bar(x+(j-0.5)*width, vals, width, label=dataset)
    ax.set_xticks(x); ax.set_xticklabels(metrics); ax.set_ylabel("Information (bits)")
    ax.set_title("Sufficiency ladder for observed versus hidden state conditioning"); ax.legend(frameon=False); ax.set_ylim(0,0.65); fig.tight_layout()
    save(fig, out_dir, "fret_sufficiency_ladder")

    # Fiber resolved
    fiber = pd.read_csv(base / "path_memory_fiber_details.csv")
    poiss_fib = fiber[(fiber["dataset"] == "poissonian") & (fiber["assay"].isin(["hidden_prev_to_hidden_next_given_observed_current", "hidden_prev_to_hidden_next_given_hidden_current_markov_control"]))].copy()
    value_col = "I_D_Z_given_Y_y_bits" if "I_D_Z_given_Y_y_bits" in poiss_fib.columns else [c for c in poiss_fib.columns if "bits" in c.lower()][0]
    label_col = "Y" if "Y" in poiss_fib.columns else poiss_fib.columns[0]
    n_col = "n" if "n" in poiss_fib.columns else None
    labels=[]
    for _, r in poiss_fib.iterrows():
        base_lab = (r"$Y_t=$" if "observed_current" in r["assay"] else r"$X_t=$") + str(int(r[label_col]))
        labels.append(base_lab + ("\n" + f"n={int(r[n_col])}" if n_col else ""))
    fig, ax = plt.subplots(figsize=(6.1, 3.7))
    x=np.arange(len(poiss_fib)); ax.bar(x, poiss_fib[value_col])
    ax.set_xticks(x); ax.set_xticklabels(labels); ax.set_ylabel(r"Fiber-level $I(D;Z\mid \cdot)$ (bits)")
    ax.set_title("Fiber-level response memory and hidden-state control")
    for i, val in enumerate(poiss_fib[value_col]): ax.text(i, val + 0.012 if val > 0.01 else val + 0.004, f"{val:.4f}", ha="center", va="bottom", fontsize=8)
    ax.set_ylim(0, 0.56); fig.tight_layout(); save(fig, out_dir, "fret_fiber_resolved_cmi_control")

    # Balanced controls
    columns = [("I(D;Z|Y)_bits", r"response after $Y$"), ("I(D;Z|X)_bits", r"hidden-state control"), ("I(Yprev;Ynext|Y)_bits", r"observed-only memory")]
    data = [bal_poiss[c].to_numpy() for c,_ in columns]
    fig, ax = plt.subplots(figsize=(6.0, 3.8)); ax.boxplot(data, positions=np.arange(len(columns)), widths=0.45, showfliers=False)
    rng=np.random.default_rng(7)
    for i, vals in enumerate(data):
        idx=rng.choice(len(vals), size=min(180, len(vals)), replace=False)
        ax.scatter(np.full(len(idx), i)+rng.normal(0,0.045,len(idx)), vals[idx], s=8, alpha=0.25)
    ax.set_xticks(np.arange(len(columns))); ax.set_xticklabels([l for _,l in columns]); ax.set_ylabel("Information (bits)")
    ax.set_title("Endpoint-matched resamples: response signal versus controls"); ax.set_ylim(0,0.65); fig.tight_layout()
    save(fig, out_dir, "fret_balanced_resample_controls_boxstrip")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", required=True)
    parser.add_argument("--out-dir", default="./figures_pdf")
    args = parser.parse_args(); main(args.data_dir, args.out_dir)
