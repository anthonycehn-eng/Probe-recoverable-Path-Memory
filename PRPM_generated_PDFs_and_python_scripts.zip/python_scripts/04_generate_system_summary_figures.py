#!/usr/bin/env python3
"""
Generate whole-framework/evidence-summary figures from the processed package.
Usage:
  python 04_generate_system_summary_figures.py --data-dir ./prpm_full_data_package --out-dir ./figures_pdf
"""
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle
from matplotlib.lines import Line2D

blue="#4c78a8"; light_blue="#9ecae1"; green="#74c476"; dark_green="#238b45"; gray="#6b6b6b"; light_gray="#e6e6e6"; mid_gray="#bdbdbd"; dark="#2f2f2f"

def save(fig,out_dir,name):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    fig.savefig(out/f"{name}.pdf",bbox_inches="tight"); fig.savefig(out/f"{name}.png",dpi=300,bbox_inches="tight"); plt.close(fig)

def main(data_dir,out_dir):
    base=Path(data_dir)
    fret_summary=pd.read_csv(base/"02_ground_truth_fret_benchmark/path_memory_summary.csv")
    balanced=pd.read_csv(base/"02_ground_truth_fret_benchmark/balanced_fiber_matched_resamples.csv")
    myosin_summary=pd.read_csv(base/"04_myosin5b_motor_pilot/myosin5b_path_memory_pilot_summary.csv")
    ribo_pairs=pd.read_csv(base/"05_riboswitch_aggregate_module/riboswitch_near_deltaG_rate_degeneracy_pairs.csv")
    burst_gmm=pd.read_csv(base/"03_smfret_burst_benchmark/smfret_hdf5_Eraw_gmm2_summary.csv")
    poiss=fret_summary[fret_summary["dataset"]=="poissonian"].iloc[0]; cross=fret_summary[fret_summary["dataset"]!="poissonian"].iloc[0]
    bal_poiss=balanced[balanced["dataset"]=="poissonian"]; bal_cross=balanced[balanced["dataset"]!="poissonian"]
    myo=myosin_summary.iloc[0]
    def find_col(terms):
        for c in myosin_summary.columns:
            if all(t in c for t in terms): return c
        return None
    myo_endpoint=float(myo[find_col(["I(D;Y"])]) if find_col(["I(D;Y"]) else 0.04031
    myo_cmi=float(myo[find_col(["I(D;Z|Y"])]) if find_col(["I(D;Z|Y"]) else 0.000279
    ctmc_endpoint=0.0; ctmc_non=0.00641; ctmc_lump=0.0; ctmc_storage=0.05935; ctmc_washout=3.92e-8
    poiss_endpoint=float(poiss["I(D_hidden_prev;Y_obs_current)_bits"]); poiss_cmi=float(poiss["I(D_hidden_prev;Z_hidden_next|Y_obs_current)_bits"]); poiss_hidden_control=float(poiss["I(D_hidden_prev;Z_hidden_next|X_current)_bits_markov_sufficiency_control"])
    cross_endpoint=float(cross["I(D_hidden_prev;Y_obs_current)_bits"]); cross_cmi=float(cross["I(D_hidden_prev;Z_hidden_next|Y_obs_current)_bits"]); cross_hidden_control=float(cross["I(D_hidden_prev;Z_hidden_next|X_current)_bits_markov_sufficiency_control"])
    bal_poiss_cmi=float(bal_poiss["I(D;Z|Y)_bits"].mean()); bal_poiss_sd=float(bal_poiss["I(D;Z|Y)_bits"].std()); bal_poiss_hidden_control=float(bal_poiss["I(D;Z|X)_bits"].mean())
    burst_all=burst_gmm[burst_gmm["file_or_group"]=="all_files"].iloc[0]; burst_low=float(burst_all["gmm2_mean_low_E"]); burst_high=float(burst_all["gmm2_mean_high_E"])
    ribo_kdock_fc=float(ribo_pairs.iloc[0]["kdock_foldchange"])

    # Option 1 phase diagram
    phase=pd.DataFrame([
        {"label":"CTMC non-lumpable","x":ctmc_endpoint,"y":ctmc_non,"kind":"Synthetic"},
        {"label":"CTMC lumpable","x":ctmc_endpoint,"y":ctmc_lump,"kind":"Control"},
        {"label":"Poissonian smFRET raw","x":poiss_endpoint,"y":poiss_cmi,"kind":"Benchmark"},
        {"label":"Poissonian smFRET balanced","x":0.0,"y":bal_poiss_cmi,"kind":"Benchmark"},
        {"label":"High-separability smFRET","x":cross_endpoint,"y":cross_cmi,"kind":"Control"},
        {"label":"Myosin local pilot","x":myo_endpoint,"y":myo_cmi,"kind":"Public/pilot"},])
    fig,ax=plt.subplots(figsize=(6.6,4.6)); ax.add_patch(Rectangle((0,0.02),0.08,0.62,facecolor=light_blue,alpha=0.23,edgecolor="none")); ax.add_patch(Rectangle((0.08,0.0),0.60,0.02,facecolor=light_gray,alpha=0.7,edgecolor="none"))
    ax.text(0.006,0.585,"severe PRPM\nregion",fontsize=9,color=dark); ax.text(0.34,0.012,"response-sufficient / null",fontsize=8,color=gray,ha="center")
    markers={"Synthetic":"o","Benchmark":"D","Control":"s","Public/pilot":"^"}; colors={"Synthetic":dark_green,"Benchmark":blue,"Control":gray,"Public/pilot":green}
    for _,r in phase.iterrows():
        ax.scatter(r["x"],r["y"],marker=markers[r["kind"]],s=78,color=colors[r["kind"]],edgecolor="white",linewidth=0.8,zorder=5)
        offset=(8,-14) if r["label"]=="CTMC lumpable" else (8,8) if r["label"]=="CTMC non-lumpable" else (8,-6) if r["label"]=="Myosin local pilot" else (-8,9) if r["x"]>0.4 else (9,8)
        ax.annotate(r["label"],(r["x"],r["y"]),xytext=offset,textcoords="offset points",fontsize=8,ha=("right" if r["x"]>0.4 else "left"),va="bottom")
    ax.set_xlim(-0.015,0.58); ax.set_ylim(-0.015,0.62); ax.set_xlabel(r"Visible endpoint imprint, $I(D;Y_T)$ (bits)"); ax.set_ylabel(r"Future response recoverability, $I(D;Z\mid Y_T)$ (bits)"); ax.set_title("PRPM sufficiency phase diagram")
    ax.legend(handles=[Line2D([0],[0],marker=markers[k],color="none",markerfacecolor=colors[k],markeredgecolor="white",markersize=8,label=k) for k in ["Synthetic","Benchmark","Control","Public/pilot"]],frameon=False,loc="upper right"); fig.tight_layout(); save(fig,out_dir,"option1_prpm_sufficiency_phase_diagram")

    # Option 2 matrix
    rows=["Finite-state theory","Synthetic CTMC","Ground-truth smFRET","Public smFRET bursts","Myosin-5B","Riboswitch aggregates"]; cols=[r"$\pi/Y$",r"$D$",r"$Q$",r"$Z$",r"$X$","Direct PRPM"]
    status=np.array([[2,2,2,2,2,2],[2,2,2,2,2,2],[2,2,1,2,2,2],[2,0,0,0,0,0],[2,1,0,1,0,0],[2,1,0,1,0,0]],float)
    text=np.array([["defined","defined","defined","defined","known","yes"],["known","known","known","known","known","yes"],["noisy","history","traj.","known","known","yes"],["bursts","none","none","none","none","no"],["speed","local","none","local","none","pilot"],[r"$\Delta G$","condition","none","rates","none","no"]],object)
    fig,ax=plt.subplots(figsize=(7.4,4.2)); rgba=np.zeros((*status.shape,4))
    for i in range(status.shape[0]):
        for j in range(status.shape[1]): rgba[i,j]=[0.45,0.77,0.46,0.75] if status[i,j]==2 else [0.62,0.79,0.88,0.75] if status[i,j]==1 else [0.85,0.85,0.85,0.75]
    ax.imshow(rgba,aspect="auto"); ax.set_xticks(np.arange(len(cols))); ax.set_xticklabels(cols); ax.set_yticks(np.arange(len(rows))); ax.set_yticklabels(rows)
    for i in range(len(rows)):
        for j in range(len(cols)): ax.text(j,i,text[i,j],ha="center",va="center",fontsize=8,color=dark)
    ax.set_xticks(np.arange(-.5,len(cols),1),minor=True); ax.set_yticks(np.arange(-.5,len(rows),1),minor=True); ax.grid(which="minor",color="white",linestyle="-",linewidth=1.4); ax.tick_params(which="minor",bottom=False,left=False); ax.set_title("Architecture-to-evidence matrix"); fig.tight_layout(); save(fig,out_dir,"option2_architecture_evidence_matrix")

    # Option 3 stack
    fig,ax=plt.subplots(figsize=(6.3,6.1)); ax.set_xlim(0,1); ax.set_ylim(0,1); ax.axis("off")
    stack=[("Finite-state architecture",r"$\Pi\delta p_T=0,\quad \Pi e^{\tau Q}\delta p_T\neq0$",blue),("Synthetic CTMC witness",r"$I(D;Y_T)=0,\ I(D;Y_{T+1}\mid Y_T)=0.00641$",dark_green),("Ground-truth smFRET",r"$I(D_t;Z_t\mid Y_t)=0.44225;\ I(D_t;Z_t\mid X_t)\approx0$",blue),("Matched-present resampling",rf"$I(D_t;Y_t)=0,\ I(D_t;Z_t\mid Y_t)={bal_poiss_cmi:.3f}\pm{bal_poiss_sd:.3f}$",dark_green),("Public application modules",rf"bursts: {burst_low:.3f}/{burst_high:.3f}; myosin pilot negative; riboswitch {ribo_kdock_fc:.2f}$\times$",gray)]
    ys=np.linspace(0.86,0.16,len(stack))
    for idx,((title,metric,color),y) in enumerate(zip(stack,ys)):
        ax.add_patch(FancyBboxPatch((0.08,y-0.055),0.84,0.095,boxstyle="round,pad=0.012,rounding_size=0.02",facecolor="white",edgecolor=color,linewidth=1.5)); ax.text(0.5,y+0.012,title,ha="center",va="center",fontsize=11,color=dark); ax.text(0.5,y-0.023,metric,ha="center",va="center",fontsize=8.5,color=gray)
        if idx<len(stack)-1: ax.add_patch(FancyArrowPatch((0.5,y-0.06),(0.5,ys[idx+1]+0.055),arrowstyle="-|>",mutation_scale=12,linewidth=1.0,color=mid_gray))
    ax.set_title("End-to-end PRPM evidence stack",fontsize=13,pad=8); fig.tight_layout(); save(fig,out_dir,"option3_prpm_evidence_stack")

    # Option 4 ladder
    ladder=pd.DataFrame([{"module":"CTMC","Endpoint\n$I(D;Y)$":0.0,"Hidden storage\n$I(D;X|Y)$":ctmc_storage,"Response\n$I(D;Z|Y)$":ctmc_non,"Hidden-state control\n$I(D;Z|X)$":np.nan},{"module":"Poissonian\nsmFRET","Endpoint\n$I(D;Y)$":poiss_endpoint,"Hidden storage\n$I(D;X|Y)$":np.nan,"Response\n$I(D;Z|Y)$":poiss_cmi,"Hidden-state control\n$I(D;Z|X)$":poiss_hidden_control},{"module":"Balanced\nsmFRET","Endpoint\n$I(D;Y)$":0.0,"Hidden storage\n$I(D;X|Y)$":np.nan,"Response\n$I(D;Z|Y)$":bal_poiss_cmi,"Hidden-state control\n$I(D;Z|X)$":bal_poiss_hidden_control},{"module":"High-sep\nsmFRET","Endpoint\n$I(D;Y)$":cross_endpoint,"Hidden storage\n$I(D;X|Y)$":np.nan,"Response\n$I(D;Z|Y)$":cross_cmi,"Hidden-state control\n$I(D;Z|X)$":cross_hidden_control}])
    metrics=[c for c in ladder.columns if c!="module"]; x=np.arange(len(ladder["module"])); width=0.18; fig,ax=plt.subplots(figsize=(7.1,4.4)); metric_colors=[mid_gray,light_blue,green,gray]
    for k,metric in enumerate(metrics):
        vals=ladder[metric].to_numpy(dtype=float); ax.bar(x+(k-1.5)*width,np.nan_to_num(vals,nan=0.0),width,label=metric,color=metric_colors[k],edgecolor="white",linewidth=0.4)
        for i,v in enumerate(vals):
            if np.isnan(v): ax.text(x[i]+(k-1.5)*width,0.012,"n/a",ha="center",va="bottom",fontsize=7,rotation=90,color=gray)
    ax.set_xticks(x); ax.set_xticklabels(ladder["module"]); ax.set_ylabel("Information (bits)"); ax.set_title("Information decomposition ladder"); ax.set_ylim(0,0.62); ax.legend(frameon=False,fontsize=8,ncol=2,loc="upper right"); fig.tight_layout(); save(fig,out_dir,"option4_information_decomposition_ladder")

    # Option 5 closure map
    fig,ax=plt.subplots(figsize=(7.4,4.9)); ax.set_xlim(0,1); ax.set_ylim(0,1); ax.axis("off")
    ax.add_patch(FancyBboxPatch((0.06,0.42),0.25,0.16,boxstyle="round,pad=0.012,rounding_size=0.025",facecolor="white",edgecolor=blue,linewidth=1.5)); ax.text(0.185,0.515,r"hidden mode",ha="center",va="center",fontsize=11); ax.text(0.185,0.475,r"$\delta p_T\in\ker\Pi$",ha="center",va="center",fontsize=10,color=gray)
    branches=[("lumpable closure",r"$Q(\ker\Pi)\subseteq\ker\Pi$",r"$I(D;Z\mid Y)=0$",0.80,blue),("non-lumpable readout",r"$\Pi e^{\tau Q}\delta p_T\neq0$",r"CTMC: $0.00641$ bits",0.50,dark_green),("hidden equilibration",r"$\mu_y^{0}\to\mu_y^{1}$",r"washout: $3.92\times10^{-8}$ bits",0.20,gray)]
    for title,eq,metric,y,color in branches:
        ax.add_patch(FancyArrowPatch((0.31,0.50),(0.54,y),arrowstyle="-|>",mutation_scale=13,linewidth=1.2,color=color)); ax.add_patch(FancyBboxPatch((0.56,y-0.075),0.37,0.15,boxstyle="round,pad=0.012,rounding_size=0.02",facecolor="white",edgecolor=color,linewidth=1.35)); ax.text(0.745,y+0.035,title,ha="center",va="center",fontsize=10.5,color=dark); ax.text(0.745,y,eq,ha="center",va="center",fontsize=9.2,color=gray); ax.text(0.745,y-0.035,metric,ha="center",va="center",fontsize=9,color=color)
    ax.text(0.5,0.94,"Coarse-state closure map",ha="center",fontsize=13); ax.text(0.5,0.90,"Three fates of an observation-null preparation difference",ha="center",fontsize=9,color=gray); fig.tight_layout(); save(fig,out_dir,"option5_coarse_state_closure_map")

if __name__ == "__main__":
    parser=argparse.ArgumentParser(); parser.add_argument("--data-dir",required=True); parser.add_argument("--out-dir",default="./figures_pdf")
    args=parser.parse_args(); main(args.data_dir,args.out_dir)
