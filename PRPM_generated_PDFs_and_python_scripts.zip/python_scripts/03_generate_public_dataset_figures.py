#!/usr/bin/env python3
"""
Generate public biophysical application figures from the processed package.
Usage:
  python 03_generate_public_dataset_figures.py --data-dir ./prpm_full_data_package --out-dir ./figures_pdf
"""
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import spearmanr

blue = "#4c78a8"; light_blue = "#9ecae1"; green = "#74c476"; dark_green = "#238b45"; gray = "#6b6b6b"

def save(fig, out_dir, name):
    out=Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    fig.savefig(out / f"{name}.pdf", bbox_inches="tight")
    fig.savefig(out / f"{name}.png", dpi=300, bbox_inches="tight")
    plt.close(fig)

def main(data_dir, out_dir):
    base=Path(data_dir)
    bursts=pd.read_csv(base / "03_smfret_burst_benchmark/smfret_hdf5_bursts_threshold50.csv")
    gmm=pd.read_csv(base / "03_smfret_burst_benchmark/smfret_hdf5_Eraw_gmm2_summary.csv")
    valid=bursts[bursts["valid_basic"]].copy(); g_all=gmm[gmm["file_or_group"]=="all_files"].iloc[0]
    fig, ax=plt.subplots(figsize=(6.0,3.8))
    ax.hist(valid["E_raw"], bins=70, density=False, color=light_blue, edgecolor="none", alpha=0.9)
    ax.axvline(g_all["gmm2_mean_low_E"], linestyle="--", linewidth=1.25, color=dark_green, label=f"low-E mean = {g_all['gmm2_mean_low_E']:.3f}")
    ax.axvline(g_all["gmm2_mean_high_E"], linestyle="--", linewidth=1.25, color=blue, label=f"high-E mean = {g_all['gmm2_mean_high_E']:.3f}")
    ax.set_xlabel(r"Raw burst FRET efficiency $E_{\rm raw}$"); ax.set_ylabel("Valid bursts")
    ax.set_title("Public smFRET burst benchmark: latent FRET mixture"); ax.legend(frameon=False); fig.tight_layout()
    save(fig,out_dir,"public_smfret_burst_Eraw_mixture")

    myo=pd.read_csv(base / "04_myosin5b_motor_pilot/myosin5b_paper_table1_metadata.csv")
    rho,p=spearmanr(np.log10(myo["ATP_uM"]), myo["paper_velocity_nm_s"])
    fig,ax=plt.subplots(figsize=(5.6,3.8))
    ax.scatter(myo["ATP_uM"], myo["paper_velocity_nm_s"], s=55, color=green, edgecolor=dark_green, linewidth=0.6)
    for _,r in myo.iterrows():
        if r.get("measure", -1) in [0,3,8,12]:
            ax.annotate(str(int(r["measure"])), (r["ATP_uM"], r["paper_velocity_nm_s"]), xytext=(4,4), textcoords="offset points", fontsize=8, color=gray)
    ax.set_xscale("log"); ax.set_xlabel(r"ATP concentration ($\mu$M, log scale)"); ax.set_ylabel("Reported velocity (nm/s)")
    ax.set_title("Public myosin-5B trajectories: ATP-dependent motor response")
    ax.text(0.04,0.92,rf"Spearman $\rho={rho:.3f}$, $p={p:.1e}$", transform=ax.transAxes, fontsize=9, va="top")
    fig.tight_layout(); save(fig,out_dir,"public_myosin5b_velocity_vs_atp")

    ribo=pd.read_csv(base / "05_riboswitch_aggregate_module/riboswitch_merged_derived.csv")
    pairs=pd.read_csv(base / "05_riboswitch_aggregate_module/riboswitch_near_deltaG_rate_degeneracy_pairs.csv")
    top=pairs.iloc[0]
    fig,ax=plt.subplots(figsize=(6.2,4.1))
    ax.scatter(ribo["deltaG_kcal_mol"], ribo["k_dock"], s=38, color=light_blue, edgecolor=blue, linewidth=0.4, alpha=0.85)
    for suffix, marker in [("a","D"),("b","s")]:
        x=top[f"deltaG_{suffix}"]; y=top[f"kdock_{suffix}"]; label=top[f"id_{suffix}"]
        ax.scatter([x],[y],s=75,marker=marker,color=green,edgecolor=dark_green,linewidth=0.8)
        ax.annotate(str(label).replace(":","\n"),(x,y),xytext=(6,6),textcoords="offset points",fontsize=8)
    ax.plot([top["deltaG_a"],top["deltaG_b"]],[top["kdock_a"],top["kdock_b"]],linestyle="--",linewidth=1.1,color=dark_green)
    ax.set_yscale("log"); ax.set_xlabel(r"Aggregate folding free energy $\Delta G_{\rm fold}$ (kcal/mol)"); ax.set_ylabel(r"$k_{\rm dock}$ (s$^{-1}$, log scale)")
    ax.set_title("Riboswitch aggregates: near-matched macrostate, divergent kinetics")
    ax.text(0.03,0.94,rf"$|\Delta G_a-\Delta G_b|={top['deltaG_absdiff']:.4f}$ kcal/mol; $k_{{dock}}$ differs {top['kdock_foldchange']:.2f}$\times$", transform=ax.transAxes, va="top", fontsize=9)
    fig.tight_layout(); save(fig,out_dir,"public_riboswitch_deltaG_kdock_degeneracy")

if __name__ == "__main__":
    parser=argparse.ArgumentParser(); parser.add_argument("--data-dir", required=True); parser.add_argument("--out-dir", default="./figures_pdf")
    args=parser.parse_args(); main(args.data_dir,args.out_dir)
